# LMFCNet: Lightweight Multimodal Feature Cross Network for ECG–PCG Analysis

A complete, modular, research-grade PyTorch pipeline for synchronized ECG +
PCG analysis on the **EPHNOGRAM** dataset (WFDB format only), built around a
novel lightweight architecture — **LMFCNet** — designed for embedded
(STM32 / CMSIS-NN / TFLite Micro) deployment.

- **Model size:** 11.2K parameters (well under the 100K budget), ~44 KB in
  float32, expected well under 0.5 MB after INT8 quantization.
- **All parameters are config-driven** — see `config.yaml`, no hardcoded
  constants anywhere in `src/`.
- Verified end-to-end on synthetic WFDB data during development (see
  *Verification* below) — every stage runs without errors.

---

## 1. Project Structure

```
EPHNOGRAM/
├── data/WFDB/                  # place EPHNOGRAM *.hea/*.dat files here
├── src/
│   ├── config.py                # typed YAML config loader
│   ├── preprocessing/
│   │   ├── verify.py             # WFDB record validation + report
│   │   ├── filter.py              # Bessel/Butterworth/Cheby1/Elliptic/FIR + notch
│   │   ├── quality.py             # NaN/Inf/flat/clip/noise + Signal Quality Index
│   │   ├── normalization.py       # Z-score / Min-Max / Robust / Decimal
│   │   ├── windows.py             # 5s windows, 50% overlap, rejection
│   │   └── hdf5.py                # full pipeline -> compressed HDF5 dataset
│   ├── dataset/
│   │   ├── loader.py               # PyTorch Dataset + subject-wise split
│   │   ├── augment.py              # noise/shift/scale/stretch/crop/mixup
│   │   └── sampler.py              # class-balanced sampler + feature-space SMOTE
│   ├── models/
│   │   ├── layers.py                # depthwise-separable conv, residual, SE block
│   │   ├── backbone.py              # per-modality CNN backbone
│   │   ├── attention.py             # ECG<->PCG cross-attention
│   │   ├── fusion.py                # feature fusion head
│   │   └── lightweight_model.py     # LMFCNet assembly
│   ├── training/
│   │   ├── losses.py                 # CrossEntropy / label smoothing / focal
│   │   ├── metrics.py                # accuracy/P/R/F1/ROC-AUC/PR/FLOPs/latency
│   │   ├── train.py                  # AdamW + cosine schedule + early stopping
│   │   ├── validate.py               # validation loop
│   │   └── test.py                   # held-out test + full report (JSON)
│   └── export/
│       ├── onnx_export.py            # PyTorch -> ONNX
│       └── tflite_export.py          # ONNX -> TF SavedModel -> TFLite -> INT8
├── outputs/                    # reports, exported models
├── weights/                    # checkpoints
├── logs/
├── config.yaml
└── requirements.txt
```

## 2. Setup

```bash
cd EPHNOGRAM
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

Download the EPHNOGRAM dataset (WFDB version only) from PhysioNet and place
the `.hea`/`.dat` files directly under `data/WFDB/`:

```bash
wget -r -N -c -np https://physionet.org/files/ephnogram/1.0.0/WFDB/ -P data/
# then flatten so files sit directly under data/WFDB/
```

All records are read exclusively via:

```python
import wfdb
record = wfdb.rdrecord("data/WFDB/ECGPCG0001")
```

The `MAT/` version is never used anywhere in this codebase.

## 3. Training Guide (Phases 2–9)

Run each phase from the project root (so `src` is importable) or via
`python -m`:

```bash
# Phase 3 — verify every WFDB record, produce outputs/dataset_report.csv
python -m src.preprocessing.verify

# Phase 4–6 — filter, normalize, window, build compressed HDF5 dataset
python -m src.preprocessing.hdf5

# Phase 9 — train LMFCNet (AdamW, cosine LR, early stopping)
python -m src.training.train

# Phase 9 — evaluate on the held-out test split, write outputs/test_report.json
python -m src.training.test
```

All hyperparameters (filter type/order, window length/overlap, split
ratios, optimizer, loss, epochs, etc.) live in `config.yaml` — edit that
file rather than the code to change behavior.

### Label note

EPHNOGRAM is a **healthy-subject stress-test** dataset (Bruce protocol) —
it does not ship disease labels. `infer_label_from_record_name()` in
`src/preprocessing/hdf5.py` currently uses a placeholder rest-vs-stress
heuristic based on record naming; replace it with a mapping from the
EPHNOGRAM subject metadata (age, stage, protocol time) once you've joined
that CSV in, e.g. keying off Bruce-protocol stage or heart-rate zone.

## 4. Model: LMFCNet

```
ECG ─▶ Depthwise CNN ─▶ Residual ─┐
                                    ├─▶ Cross-Attention ─▶ Fusion ─▶ Classifier
PCG ─▶ Depthwise CNN ─▶ Residual ─┘
```

- Each branch: depthwise-separable stem (stride 2) → N residual
  depthwise-separable blocks → Squeeze-Excitation channel attention →
  average-pool downsample.
- **Cross-attention:** bidirectional scaled dot-product attention lets ECG
  features attend to PCG features and vice versa, projected into a small
  shared space (`attention_dim`, default 32) to control parameter growth.
- **Fusion:** global-average-pool each branch, concatenate, project through
  a small MLP with dropout.
- **Classifier:** 2-layer MLP head.

Verify parameter budget any time:

```bash
python -m src.models.lightweight_model
# LMFCNet parameters: 11,206 (11.2K)
```

## 5. Export & Embedded Deployment (Phase 10)

```
PyTorch → ONNX → TensorFlow SavedModel → TFLite → INT8 → CMSIS-NN → STM32
```

```bash
# PyTorch -> ONNX (verified working — produces outputs/lmfcnet.onnx)
python -m src.export.onnx_export

# ONNX -> TFLite (float) + TFLite (INT8) for STM32/CMSIS-NN
# Requires the heavier "export" extras:
pip install onnx2tf tensorflow --break-system-packages
python -m src.export.tflite_export
```

`tflite_export.py`'s INT8 path uses a representative-dataset generator for
calibration; swap the random placeholder in
`_representative_dataset_factory` for real training-split windows before
deploying, so the quantization ranges reflect your actual signal
distributions.

### STM32 deployment guide (outline)

1. Convert `outputs/lmfcnet_int8.tflite` to a C array with
   `xxd -i lmfcnet_int8.tflite > lmfcnet_model.h` (or STM32CubeAI's
   converter, which also reports RAM/Flash estimates directly).
2. Import into STM32CubeIDE / STM32CubeAI as a **TFLite Micro** or
   **CMSIS-NN** network; STM32CubeAI will map supported ops to
   CMSIS-NN kernels automatically where available.
3. Allocate a static tensor arena sized per STM32CubeAI's memory report
   (typically a few tens of KB for a ~11K-parameter INT8 model).
4. On-device inference loop: read 5s @ (500 Hz ECG / 1000 Hz PCG) buffer →
   quantize per the exported model's input scale/zero-point → invoke →
   dequantize logits → argmax.
5. Benchmark actual latency, RAM, and Flash usage on target hardware and
   compare against the FLOPs/latency numbers in `outputs/test_report.json`
   (produced on your training machine as a reference baseline).

## 6. Research Comparison Baselines

`src/training/metrics.py` exposes `count_flops` and `measure_inference_time`
so LMFCNet can be benchmarked head-to-head against MobileNetV2/V3,
ShuffleNetV2, EfficientNet-Lite, TinyConvNeXt, and DS-CNN on: accuracy,
F1, latency, memory, model size, parameter count, and FLOPs. Implement each
baseline as an alternate `nn.Module` and reuse the same `train.py` /
`test.py` / `metrics.py` entry points for a fair comparison.

## 7. Verification Performed During Development

Because this sandbox has no live network access to PhysioNet, the full
pipeline was validated end-to-end on **synthetic** WFDB records
(ECG-like + PCG-like signals, same channel names/format EPHNOGRAM uses):

- ✅ `verify.py` — reads and validates records, confirms ECG+PCG channels present
- ✅ `hdf5.py` — baseline removal → bandpass → notch → resample → normalize →
  window → HDF5 (gzip) all run without error
- ✅ `loader.py` — subject-wise split with no leakage, correct tensor shapes
  (ECG: 1×2500 @ 500 Hz, PCG: 1×5000 @ 1000 Hz for 5s windows)
- ✅ `lightweight_model.py` — forward pass with mismatched ECG/PCG lengths,
  **11,206 parameters**
- ✅ `train.py` / `validate.py` / `test.py` — full training loop, checkpointing,
  metrics, FLOPs/latency measurement
- ✅ `onnx_export.py` — exports and validates a working ONNX graph

Swap in the real EPHNOGRAM WFDB files under `data/WFDB/` and everything
above runs unchanged — no code changes needed, only real data.
