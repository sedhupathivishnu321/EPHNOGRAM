"""Class-balanced sampling utilities.

Provides a PyTorch ``WeightedRandomSampler`` factory for imbalanced classes,
plus an optional feature-space SMOTE helper. Per project requirements, SMOTE
must never be applied to raw signal windows — only to extracted feature
vectors, and only on the training split, strictly after the train/test
split has been performed.
"""

from __future__ import annotations

import logging

import numpy as np
from imblearn.over_sampling import SMOTE
from torch.utils.data import WeightedRandomSampler

logger = logging.getLogger(__name__)


def build_weighted_sampler(labels: np.ndarray) -> WeightedRandomSampler:
    """Build a WeightedRandomSampler that balances class frequency per batch.

    Args:
        labels: 1D array of integer class labels for the training set.

    Returns:
        A configured ``WeightedRandomSampler``.
    """
    labels = np.asarray(labels)
    class_counts = np.bincount(labels)
    class_weights = 1.0 / np.clip(class_counts, 1, None)
    sample_weights = class_weights[labels]
    logger.info("Class counts: %s -> sampler built with inverse-frequency weights", class_counts.tolist())
    return WeightedRandomSampler(weights=sample_weights, num_samples=len(sample_weights), replacement=True)


def apply_feature_smote(
    features_train: np.ndarray, labels_train: np.ndarray, random_state: int = 42
) -> tuple[np.ndarray, np.ndarray]:
    """Apply SMOTE oversampling to extracted feature vectors (training set only).

    Args:
        features_train: Feature matrix of shape (n_samples, n_features)
            extracted from the *training* split only.
        labels_train: Corresponding integer labels.
        random_state: RNG seed for reproducibility.

    Returns:
        Tuple (features_resampled, labels_resampled).

    Raises:
        ValueError: If called with fewer than 2 classes present.
    """
    if len(np.unique(labels_train)) < 2:
        raise ValueError("SMOTE requires at least 2 classes in the training labels.")
    smote = SMOTE(random_state=random_state)
    features_res, labels_res = smote.fit_resample(features_train, labels_train)
    logger.info(
        "SMOTE applied: %d -> %d samples (train-only, feature-space)",
        len(labels_train), len(labels_res),
    )
    return features_res, labels_res
