"""Signal-domain data augmentation, applied only to the training split.

Implements: Gaussian noise, random shift, amplitude scaling, time stretch,
random crop, and MixUp (batch-level). SMOTE is intentionally NOT applied
here (never on raw signals) — see :mod:`src.dataset.sampler` for the
feature-space SMOTE utility, which must only run on the training split
after the train/test split has already been made.
"""

from __future__ import annotations

import logging

import numpy as np
from scipy.signal import resample

from src.config import AugmentationConfig

logger = logging.getLogger(__name__)


def add_gaussian_noise(x: np.ndarray, std: float, rng: np.random.Generator) -> np.ndarray:
    """Add zero-mean Gaussian noise scaled relative to the signal's own std."""
    sigma = std * (np.std(x) + 1e-8)
    return x + rng.normal(0.0, sigma, size=x.shape).astype(x.dtype)


def random_shift(x: np.ndarray, max_shift_ratio: float, rng: np.random.Generator) -> np.ndarray:
    """Circularly shift the signal by a random offset."""
    max_shift = int(len(x) * max_shift_ratio)
    if max_shift == 0:
        return x
    shift = int(rng.integers(-max_shift, max_shift + 1))
    return np.roll(x, shift)


def amplitude_scale(x: np.ndarray, scale_range: tuple[float, float], rng: np.random.Generator) -> np.ndarray:
    """Multiply the signal by a random scalar within the given range."""
    scale = rng.uniform(scale_range[0], scale_range[1])
    return x * scale


def time_stretch(x: np.ndarray, stretch_range: tuple[float, float], rng: np.random.Generator) -> np.ndarray:
    """Resample the signal to simulate a small time-stretch, then crop/pad back to original length."""
    factor = rng.uniform(stretch_range[0], stretch_range[1])
    n = len(x)
    n_stretched = max(2, int(round(n * factor)))
    stretched = resample(x, n_stretched)
    if n_stretched >= n:
        start = (n_stretched - n) // 2
        return stretched[start:start + n]
    pad_total = n - n_stretched
    pad_left = pad_total // 2
    pad_right = pad_total - pad_left
    return np.pad(stretched, (pad_left, pad_right), mode="edge")


def random_crop(x: np.ndarray, crop_ratio: float, rng: np.random.Generator) -> np.ndarray:
    """Crop a random contiguous sub-window then pad back to the original length (edge padding)."""
    n = len(x)
    crop_len = max(2, int(round(n * crop_ratio)))
    if crop_len >= n:
        return x
    start = int(rng.integers(0, n - crop_len + 1))
    cropped = x[start:start + crop_len]
    pad_total = n - crop_len
    pad_left = pad_total // 2
    pad_right = pad_total - pad_left
    return np.pad(cropped, (pad_left, pad_right), mode="edge")


def mixup(
    x1: np.ndarray, y1: int, x2: np.ndarray, y2: int, alpha: float, rng: np.random.Generator
) -> tuple[np.ndarray, np.ndarray]:
    """Mix two signals and their one-hot labels using a Beta(alpha, alpha) weight.

    Returns:
        Tuple (mixed_signal, soft_label) where soft_label is a 2-vector of
        class weights (only meaningful for binary/few-class setups; extend
        as needed for more classes).
    """
    lam = rng.beta(alpha, alpha) if alpha > 0 else 1.0
    mixed = lam * x1 + (1 - lam) * x2
    soft_label = np.array([lam if y1 == 0 else 1 - lam, lam if y1 == 1 else 1 - lam])
    return mixed, soft_label


class Augmenter:
    """Applies a random subset of signal augmentations to an (ECG, PCG) pair."""

    def __init__(self, cfg: AugmentationConfig, seed: int | None = None) -> None:
        self.cfg = cfg
        self.rng = np.random.default_rng(seed)

    def __call__(self, ecg: np.ndarray, pcg: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        """Apply noise/shift/scale/stretch/crop augmentations to both channels.

        Each augmentation is applied independently with 50% probability so
        that a variety of augmented examples are produced across epochs.
        """
        for x_name, x in (("ecg", ecg), ("pcg", pcg)):
            pass  # placeholder to keep structure explicit; actual ops below

        def _augment_one(x: np.ndarray) -> np.ndarray:
            if self.rng.random() < 0.5:
                x = add_gaussian_noise(x, self.cfg.gaussian_noise_std, self.rng)
            if self.rng.random() < 0.5:
                x = random_shift(x, self.cfg.max_shift_ratio, self.rng)
            if self.rng.random() < 0.5:
                x = amplitude_scale(x, tuple(self.cfg.amplitude_scale_range), self.rng)
            if self.rng.random() < 0.3:
                x = time_stretch(x, tuple(self.cfg.time_stretch_range), self.rng)
            if self.rng.random() < 0.3:
                x = random_crop(x, self.cfg.random_crop_ratio, self.rng)
            return x.astype(np.float32)

        return _augment_one(ecg), _augment_one(pcg)
