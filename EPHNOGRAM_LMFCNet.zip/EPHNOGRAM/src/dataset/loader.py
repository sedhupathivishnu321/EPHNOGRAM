"""PyTorch Dataset and subject-wise splitting for the EPHNOGRAM HDF5 store."""

from __future__ import annotations

import logging
from pathlib import Path

import h5py
import numpy as np
import torch
from torch.utils.data import Dataset

from src.config import Config
from src.dataset.augment import Augmenter

logger = logging.getLogger(__name__)


def subject_wise_split(
    records: np.ndarray, train_ratio: float, val_ratio: float, test_ratio: float, seed: int = 42
) -> tuple[set, set, set]:
    """Split unique subjects/records into train/val/test sets, preventing leakage.

    Args:
        records: Array of record names, one per window (may repeat).
        train_ratio: Fraction of subjects for training.
        val_ratio: Fraction of subjects for validation.
        test_ratio: Fraction of subjects for testing.
        seed: RNG seed for reproducibility.

    Returns:
        Tuple of three sets: (train_subjects, val_subjects, test_subjects).
    """
    total = train_ratio + val_ratio + test_ratio
    if not np.isclose(total, 1.0, atol=1e-6):
        raise ValueError(f"Split ratios must sum to 1.0, got {total}")

    unique_subjects = np.unique(records)
    rng = np.random.default_rng(seed)
    rng.shuffle(unique_subjects)

    n = len(unique_subjects)
    n_train = int(round(n * train_ratio))
    n_val = int(round(n * val_ratio))

    train_subj = set(unique_subjects[:n_train])
    val_subj = set(unique_subjects[n_train:n_train + n_val])
    test_subj = set(unique_subjects[n_train + n_val:])

    logger.info(
        "Subject-wise split: %d train, %d val, %d test subjects (of %d total)",
        len(train_subj), len(val_subj), len(test_subj), n,
    )
    return train_subj, val_subj, test_subj


class EphnogramDataset(Dataset):
    """PyTorch Dataset serving synchronized ECG/PCG windows from an HDF5 file.

    Each item is a dict with keys ``ecg`` (1, T_ecg), ``pcg`` (1, T_pcg), and
    ``label`` (scalar long tensor). Data stays on disk (lazy-loaded via
    h5py) to keep memory usage low.
    """

    def __init__(
        self,
        hdf5_path: str | Path,
        subjects: set[str] | None = None,
        augmenter: Augmenter | None = None,
        train: bool = False,
    ) -> None:
        """
        Args:
            hdf5_path: Path to the HDF5 file produced by ``build_hdf5_dataset``.
            subjects: If given, restrict to windows whose record name is in
                this set (used to implement subject-wise train/val/test splits).
            augmenter: Optional :class:`Augmenter` applied only when
                ``train=True``.
            train: Whether this dataset instance represents the training split.
        """
        self.hdf5_path = str(hdf5_path)
        self.train = train
        self.augmenter = augmenter

        with h5py.File(self.hdf5_path, "r") as hf:
            all_records = np.array([r.decode() if isinstance(r, bytes) else r for r in hf["metadata"]["record"][:]])
            all_labels = hf["metadata"]["label"][:]
            all_indices = hf["metadata"]["window_index"][:]

        if subjects is not None:
            mask = np.array([r in subjects for r in all_records])
        else:
            mask = np.ones(len(all_records), dtype=bool)

        self.keys = [f"{r}_{i:05d}" for r, i in zip(all_records[mask], all_indices[mask])]
        self.labels = all_labels[mask]
        self.records = all_records[mask]

        logger.info("EphnogramDataset: %d windows loaded (train=%s)", len(self.keys), train)

    def __len__(self) -> int:
        return len(self.keys)

    def __getitem__(self, idx: int) -> dict:
        key = self.keys[idx]
        with h5py.File(self.hdf5_path, "r") as hf:
            ecg = hf["ecg"][key][:].astype(np.float32)
            pcg = hf["pcg"][key][:].astype(np.float32)
        label = int(self.labels[idx])

        if self.train and self.augmenter is not None:
            ecg, pcg = self.augmenter(ecg, pcg)

        return {
            "ecg": torch.from_numpy(ecg).unsqueeze(0),
            "pcg": torch.from_numpy(pcg).unsqueeze(0),
            "label": torch.tensor(label, dtype=torch.long),
        }


def build_datasets(cfg: Config) -> tuple[EphnogramDataset, EphnogramDataset, EphnogramDataset]:
    """Build train/val/test :class:`EphnogramDataset` instances from config.

    Args:
        cfg: Global configuration.

    Returns:
        Tuple (train_dataset, val_dataset, test_dataset).
    """
    with h5py.File(cfg.hdf5.output_path, "r") as hf:
        records = np.array([r.decode() if isinstance(r, bytes) else r for r in hf["metadata"]["record"][:]])

    train_subj, val_subj, test_subj = subject_wise_split(
        records, cfg.split.train, cfg.split.val, cfg.split.test, seed=cfg.seed
    )

    augmenter = Augmenter(cfg.augmentation) if cfg.augmentation.enable else None

    train_ds = EphnogramDataset(cfg.hdf5.output_path, subjects=train_subj, augmenter=augmenter, train=True)
    val_ds = EphnogramDataset(cfg.hdf5.output_path, subjects=val_subj, augmenter=None, train=False)
    test_ds = EphnogramDataset(cfg.hdf5.output_path, subjects=test_subj, augmenter=None, train=False)
    return train_ds, val_ds, test_ds
