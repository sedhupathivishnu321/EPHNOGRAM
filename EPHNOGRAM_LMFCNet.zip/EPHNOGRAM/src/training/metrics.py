"""Evaluation metrics: accuracy, precision, recall, F1, ROC-AUC, PR curve, confusion matrix."""

from __future__ import annotations

import time
from dataclasses import dataclass, field

import numpy as np
import torch
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    f1_score,
    precision_recall_curve,
    precision_score,
    recall_score,
    roc_auc_score,
)


@dataclass
class EpochMetrics:
    accuracy: float
    precision: float
    recall: float
    f1: float
    roc_auc: float
    confusion: np.ndarray
    pr_curve: tuple = field(default=None)


def compute_classification_metrics(
    y_true: np.ndarray, y_pred: np.ndarray, y_prob: np.ndarray | None = None
) -> EpochMetrics:
    """Compute the full evaluation metric suite for one epoch/split.

    Args:
        y_true: Ground-truth integer labels, shape (N,).
        y_pred: Predicted integer labels, shape (N,).
        y_prob: Optional predicted probability of the positive class, shape (N,),
            required for ROC-AUC / PR curve (binary classification only).

    Returns:
        Populated :class:`EpochMetrics`.
    """
    if len(y_true) == 0:
        return EpochMetrics(
            accuracy=float("nan"), precision=float("nan"), recall=float("nan"),
            f1=float("nan"), roc_auc=float("nan"), confusion=np.zeros((0, 0)), pr_curve=None,
        )

    acc = accuracy_score(y_true, y_pred)
    prec = precision_score(y_true, y_pred, average="binary", zero_division=0)
    rec = recall_score(y_true, y_pred, average="binary", zero_division=0)
    f1 = f1_score(y_true, y_pred, average="binary", zero_division=0)
    cm = confusion_matrix(y_true, y_pred)

    roc_auc = float("nan")
    pr_curve = None
    if y_prob is not None and len(np.unique(y_true)) == 2:
        try:
            roc_auc = roc_auc_score(y_true, y_prob)
            precisions, recalls, thresholds = precision_recall_curve(y_true, y_prob)
            pr_curve = (precisions, recalls, thresholds)
        except ValueError:
            pass

    return EpochMetrics(accuracy=acc, precision=prec, recall=rec, f1=f1, roc_auc=roc_auc, confusion=cm, pr_curve=pr_curve)


def measure_inference_time(model: torch.nn.Module, ecg: torch.Tensor, pcg: torch.Tensor, n_runs: int = 50) -> float:
    """Measure average single-sample CPU inference latency in milliseconds.

    Args:
        model: Model in eval mode.
        ecg: Example ECG input, shape (1, 1, T_ecg).
        pcg: Example PCG input, shape (1, 1, T_pcg).
        n_runs: Number of timed forward passes to average over.

    Returns:
        Average inference time in milliseconds.
    """
    model.eval()
    with torch.no_grad():
        for _ in range(5):  # warmup
            model(ecg, pcg)
        start = time.perf_counter()
        for _ in range(n_runs):
            model(ecg, pcg)
        elapsed = time.perf_counter() - start
    return (elapsed / n_runs) * 1000.0


def count_flops(model: torch.nn.Module, ecg_shape: tuple, pcg_shape: tuple) -> int:
    """Estimate FLOPs via a forward hook counting multiply-adds for Conv1d/Linear layers.

    Args:
        model: The model to profile.
        ecg_shape: Example ECG input shape, e.g. (1, 1, 2500).
        pcg_shape: Example PCG input shape, e.g. (1, 1, 5000).

    Returns:
        Estimated total FLOPs (multiply-adds) for one forward pass.
    """
    flops = {"total": 0}
    hooks = []

    def conv_hook(module, inp, out):
        out_shape = out.shape  # (B, C_out, L_out)
        kernel_flops = module.kernel_size[0] * (module.in_channels // module.groups)
        flops["total"] += kernel_flops * out_shape[1] * out_shape[2]

    def linear_hook(module, inp, out):
        flops["total"] += module.in_features * module.out_features

    for m in model.modules():
        if isinstance(m, torch.nn.Conv1d):
            hooks.append(m.register_forward_hook(conv_hook))
        elif isinstance(m, torch.nn.Linear):
            hooks.append(m.register_forward_hook(linear_hook))

    model.eval()
    with torch.no_grad():
        model(torch.randn(*ecg_shape), torch.randn(*pcg_shape))

    for h in hooks:
        h.remove()
    return flops["total"]
