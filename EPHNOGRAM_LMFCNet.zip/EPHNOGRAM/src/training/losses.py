"""Loss functions: standard cross-entropy, label smoothing, and focal loss."""

from __future__ import annotations

import torch
import torch.nn.functional as F
from torch import nn

from src.config import TrainingConfig


class FocalLoss(nn.Module):
    """Multi-class focal loss to address class imbalance.

    Args:
        gamma: Focusing parameter; higher values down-weight easy examples more.
        weight: Optional per-class weight tensor.
    """

    def __init__(self, gamma: float = 2.0, weight: torch.Tensor | None = None) -> None:
        super().__init__()
        self.gamma = gamma
        self.weight = weight

    def forward(self, logits: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        log_probs = F.log_softmax(logits, dim=-1)
        probs = log_probs.exp()
        targets_one_hot = F.one_hot(targets, num_classes=logits.shape[-1]).float()
        pt = (probs * targets_one_hot).sum(dim=-1)
        log_pt = (log_probs * targets_one_hot).sum(dim=-1)
        focal_weight = (1 - pt) ** self.gamma

        loss = -focal_weight * log_pt
        if self.weight is not None:
            class_weight = (self.weight.to(logits.device) * targets_one_hot).sum(dim=-1)
            loss = loss * class_weight
        return loss.mean()


def build_loss_fn(cfg: TrainingConfig, class_weights: torch.Tensor | None = None) -> nn.Module:
    """Construct the configured loss function.

    Args:
        cfg: Training configuration (``loss``, ``label_smoothing``, ``focal_gamma``).
        class_weights: Optional per-class weights for imbalance handling.

    Returns:
        A loss module callable as ``loss_fn(logits, targets)``.

    Raises:
        ValueError: If ``cfg.loss`` is not recognized.
    """
    if cfg.loss == "cross_entropy":
        return nn.CrossEntropyLoss(weight=class_weights)
    if cfg.loss == "label_smoothing":
        return nn.CrossEntropyLoss(weight=class_weights, label_smoothing=cfg.label_smoothing)
    if cfg.loss == "focal":
        return FocalLoss(gamma=cfg.focal_gamma, weight=class_weights)
    raise ValueError(f"Unsupported loss '{cfg.loss}'. Choose from cross_entropy|label_smoothing|focal")
