"""Validation loop shared by training and standalone evaluation."""

from __future__ import annotations

import logging

import numpy as np
import torch
import torch.nn.functional as F
from torch import nn
from torch.utils.data import DataLoader

from src.training.metrics import EpochMetrics, compute_classification_metrics

logger = logging.getLogger(__name__)


@torch.no_grad()
def evaluate(
    model: nn.Module, loader: DataLoader, loss_fn: nn.Module, device: torch.device
) -> tuple[EpochMetrics, float]:
    """Evaluate the model on a full data loader.

    Args:
        model: Model to evaluate.
        loader: DataLoader (validation or test split).
        loss_fn: Loss function used to also report mean loss.
        device: Torch device to run inference on.

    Returns:
        Tuple (metrics, mean_loss).
    """
    model.eval()
    all_labels, all_preds, all_probs = [], [], []
    running_loss = 0.0
    n_batches = 0

    for batch in loader:
        ecg = batch["ecg"].to(device)
        pcg = batch["pcg"].to(device)
        labels = batch["label"].to(device)

        logits = model(ecg, pcg)
        loss = loss_fn(logits, labels)
        running_loss += loss.item()
        n_batches += 1

        probs = F.softmax(logits, dim=-1)
        preds = torch.argmax(probs, dim=-1)

        all_labels.append(labels.cpu().numpy())
        all_preds.append(preds.cpu().numpy())
        if probs.shape[-1] == 2:
            all_probs.append(probs[:, 1].cpu().numpy())

    if len(all_labels) == 0:
        empty = np.array([])
        return compute_classification_metrics(empty, empty), float("nan")

    y_true = np.concatenate(all_labels)
    y_pred = np.concatenate(all_preds)
    y_prob = np.concatenate(all_probs) if all_probs else None

    metrics = compute_classification_metrics(y_true, y_pred, y_prob)
    mean_loss = running_loss / max(1, n_batches)
    return metrics, mean_loss
