"""Final held-out test evaluation, reporting all required metrics."""

from __future__ import annotations

import json
import logging
from pathlib import Path

import torch
from torch.utils.data import DataLoader

from src.config import Config, load_config, setup_logging
from src.dataset.loader import build_datasets
from src.models.lightweight_model import LMFCNet
from src.training.losses import build_loss_fn
from src.training.metrics import count_flops, measure_inference_time
from src.training.train import get_device
from src.training.validate import evaluate

logger = logging.getLogger(__name__)


def run_test(cfg: Config, checkpoint_path: str = "weights/lmfcnet_best.pt") -> dict:
    """Load the best checkpoint and report full test-set metrics.

    Args:
        cfg: Global configuration.
        checkpoint_path: Path to the saved model checkpoint.

    Returns:
        Dict of all computed metrics (also written to ``outputs/test_report.json``).
    """
    device = get_device(cfg.training.device)
    _, _, test_ds = build_datasets(cfg)
    test_loader = DataLoader(test_ds, batch_size=cfg.training.batch_size, shuffle=False, num_workers=cfg.training.num_workers)

    model = LMFCNet.from_config(cfg.model).to(device)
    ckpt_path = Path(checkpoint_path)
    if ckpt_path.exists():
        checkpoint = torch.load(ckpt_path, map_location=device)
        model.load_state_dict(checkpoint["model_state_dict"])
        logger.info("Loaded checkpoint from %s", ckpt_path)
    else:
        logger.warning("Checkpoint %s not found; evaluating randomly initialized model.", ckpt_path)

    loss_fn = build_loss_fn(cfg.training)
    metrics, test_loss = evaluate(model, test_loader, loss_fn, device)

    ecg_dummy = torch.randn(1, 1, cfg.preprocessing.target_fs_ecg * int(cfg.window.seconds)).to(device)
    pcg_dummy = torch.randn(1, 1, cfg.preprocessing.target_fs_pcg * int(cfg.window.seconds)).to(device)
    inference_ms = measure_inference_time(model, ecg_dummy, pcg_dummy)
    flops = count_flops(model, tuple(ecg_dummy.shape), tuple(pcg_dummy.shape))
    n_params = model.count_parameters()

    report = {
        "test_loss": test_loss,
        "accuracy": metrics.accuracy,
        "precision": metrics.precision,
        "recall": metrics.recall,
        "f1": metrics.f1,
        "roc_auc": metrics.roc_auc,
        "confusion_matrix": metrics.confusion.tolist(),
        "inference_time_ms": inference_ms,
        "flops": flops,
        "n_parameters": n_params,
    }

    out_path = Path("outputs/test_report.json")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as fh:
        json.dump(report, fh, indent=2)
    logger.info("Test report saved to %s", out_path)
    logger.info("Test metrics: %s", report)
    return report


if __name__ == "__main__":
    setup_logging()
    config = load_config("config.yaml")
    run_test(config)
