"""Main training entry point for LMFCNet on EPHNOGRAM."""

from __future__ import annotations

import logging
from pathlib import Path

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader

from src.config import Config, load_config, setup_logging
from src.dataset.loader import build_datasets
from src.dataset.sampler import build_weighted_sampler
from src.models.lightweight_model import LMFCNet
from src.training.losses import build_loss_fn
from src.training.validate import evaluate

logger = logging.getLogger(__name__)


def get_device(device_cfg: str) -> torch.device:
    """Resolve the configured device string ('auto'|'cpu'|'cuda') to a torch.device."""
    if device_cfg == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    return torch.device(device_cfg)


def build_optimizer(model: nn.Module, cfg: Config) -> torch.optim.Optimizer:
    """Build the AdamW optimizer per configuration."""
    if cfg.training.optimizer.lower() != "adamw":
        logger.warning("Only 'adamw' is implemented; falling back to AdamW regardless of config value.")
    return torch.optim.AdamW(model.parameters(), lr=cfg.training.learning_rate, weight_decay=cfg.training.weight_decay)


def build_scheduler(optimizer: torch.optim.Optimizer, cfg: Config) -> torch.optim.lr_scheduler._LRScheduler:
    """Build the cosine-annealing LR scheduler per configuration."""
    return torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=cfg.training.epochs)


def train_one_epoch(
    model: nn.Module,
    loader: DataLoader,
    optimizer: torch.optim.Optimizer,
    loss_fn: nn.Module,
    device: torch.device,
) -> float:
    """Run one full training epoch and return the mean training loss."""
    model.train()
    running_loss = 0.0
    n_batches = 0
    for batch in loader:
        ecg = batch["ecg"].to(device)
        pcg = batch["pcg"].to(device)
        labels = batch["label"].to(device)

        optimizer.zero_grad()
        logits = model(ecg, pcg)
        loss = loss_fn(logits, labels)
        loss.backward()
        optimizer.step()

        running_loss += loss.item()
        n_batches += 1
    return running_loss / max(1, n_batches)


def run_training(cfg: Config) -> str:
    """Full training run: data -> model -> optimizer -> loop -> checkpointing.

    Args:
        cfg: Global configuration.

    Returns:
        Path to the best saved model checkpoint.
    """
    torch.manual_seed(cfg.seed)
    np.random.seed(cfg.seed)

    device = get_device(cfg.training.device)
    logger.info("Training on device: %s", device)

    train_ds, val_ds, test_ds = build_datasets(cfg)

    sampler = build_weighted_sampler(train_ds.labels) if len(train_ds) > 0 else None
    train_loader = DataLoader(
        train_ds, batch_size=cfg.training.batch_size, sampler=sampler,
        shuffle=(sampler is None), num_workers=cfg.training.num_workers, drop_last=False,
    )
    val_loader = DataLoader(val_ds, batch_size=cfg.training.batch_size, shuffle=False, num_workers=cfg.training.num_workers)

    model = LMFCNet.from_config(cfg.model).to(device)
    logger.info("Model parameters: %d", model.count_parameters())

    optimizer = build_optimizer(model, cfg)
    scheduler = build_scheduler(optimizer, cfg)
    loss_fn = build_loss_fn(cfg.training)

    best_val_f1 = -1.0
    patience_counter = 0
    weights_dir = Path("weights")
    weights_dir.mkdir(parents=True, exist_ok=True)
    best_path = weights_dir / "lmfcnet_best.pt"

    for epoch in range(1, cfg.training.epochs + 1):
        train_loss = train_one_epoch(model, train_loader, optimizer, loss_fn, device)
        val_metrics, val_loss = evaluate(model, val_loader, loss_fn, device)
        scheduler.step()

        logger.info(
            "Epoch %03d/%03d | train_loss=%.4f | val_loss=%.4f | val_acc=%.4f | val_f1=%.4f | val_auc=%.4f",
            epoch, cfg.training.epochs, train_loss, val_loss,
            val_metrics.accuracy, val_metrics.f1, val_metrics.roc_auc,
        )

        val_score = val_metrics.f1 if not np.isnan(val_metrics.f1) else -train_loss
        if val_score > best_val_f1:
            best_val_f1 = val_score
            patience_counter = 0
            torch.save({"model_state_dict": model.state_dict(), "config": cfg.model.__dict__}, best_path)
            logger.info("New best model saved (val_f1=%.4f) -> %s", best_val_f1, best_path)
        else:
            patience_counter += 1
            if patience_counter >= cfg.training.early_stopping_patience:
                logger.info("Early stopping triggered at epoch %d (no improvement for %d epochs)", epoch, patience_counter)
                break

    return str(best_path)


if __name__ == "__main__":
    setup_logging()
    config = load_config("config.yaml")
    run_training(config)
