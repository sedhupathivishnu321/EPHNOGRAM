"""Convert an exported ONNX LMFCNet model to TensorFlow Lite, including INT8
quantization suitable for STM32 deployment via CMSIS-NN / TFLite Micro.

Pipeline: PyTorch -> ONNX -> TensorFlow SavedModel -> TFLite -> INT8.

Requires the optional dependencies ``onnx2tf`` and ``tensorflow``. These are
heavier packages, so they are intentionally NOT in the base requirements
that must always be installed (see requirements.txt: they are listed under
an "export" extras section) — install with:

    pip install onnx2tf tensorflow --break-system-packages
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Callable, Iterator

import numpy as np

from src.config import Config, load_config, setup_logging

logger = logging.getLogger(__name__)


def _representative_dataset_factory(
    n_ecg: int, n_pcg: int, n_samples: int = 100
) -> Callable[[], Iterator[list]]:
    """Build a representative-dataset generator for post-training INT8 calibration.

    In production, replace the random samples below with real windows drawn
    from the training split (e.g. via ``EphnogramDataset``) for accurate
    quantization ranges.
    """

    def _gen():
        rng = np.random.default_rng(0)
        for _ in range(n_samples):
            ecg = rng.normal(0, 1, size=(1, 1, n_ecg)).astype(np.float32)
            pcg = rng.normal(0, 1, size=(1, 1, n_pcg)).astype(np.float32)
            yield [ecg, pcg]

    return _gen


def onnx_to_saved_model(onnx_path: str, saved_model_dir: str) -> str:
    """Convert an ONNX model to a TensorFlow SavedModel directory using onnx2tf.

    Args:
        onnx_path: Path to the input .onnx file.
        saved_model_dir: Output directory for the TF SavedModel.

    Returns:
        The saved_model_dir path.
    """
    try:
        import onnx2tf
    except ImportError as exc:
        raise ImportError(
            "onnx2tf is required for ONNX->TFLite conversion. "
            "Install with: pip install onnx2tf tensorflow --break-system-packages"
        ) from exc

    Path(saved_model_dir).mkdir(parents=True, exist_ok=True)
    onnx2tf.convert(
        input_onnx_file_path=onnx_path,
        output_folder_path=saved_model_dir,
        non_verbose=True,
    )
    logger.info("Converted ONNX -> TF SavedModel at %s", saved_model_dir)
    return saved_model_dir


def convert_to_tflite(saved_model_dir: str, output_path: str, quantize_int8: bool = False,
                       representative_dataset: Callable | None = None) -> str:
    """Convert a TF SavedModel to a .tflite file, optionally with full INT8 quantization.

    Args:
        saved_model_dir: Path to the TF SavedModel directory.
        output_path: Destination .tflite file path.
        quantize_int8: If True, apply full integer (INT8) post-training quantization
            (required for CMSIS-NN / TFLite Micro on STM32).
        representative_dataset: Callable returning a generator of representative
            input batches, required when ``quantize_int8=True``.

    Returns:
        The output_path.
    """
    import tensorflow as tf

    converter = tf.lite.TFLiteConverter.from_saved_model(saved_model_dir)

    if quantize_int8:
        if representative_dataset is None:
            raise ValueError("representative_dataset is required for INT8 quantization.")
        converter.optimizations = [tf.lite.Optimize.DEFAULT]
        converter.representative_dataset = representative_dataset
        converter.target_spec.supported_ops = [tf.lite.OpsSet.TFLITE_BUILTINS_INT8]
        converter.inference_input_type = tf.int8
        converter.inference_output_type = tf.int8

    tflite_model = converter.convert()

    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "wb") as fh:
        fh.write(tflite_model)

    size_kb = len(tflite_model) / 1024
    logger.info("TFLite model written to %s (%.1f KB, int8=%s)", output_path, size_kb, quantize_int8)
    return output_path


def export_full_pipeline(cfg: Config) -> dict:
    """Run the full ONNX -> SavedModel -> TFLite (float + INT8) pipeline.

    Args:
        cfg: Global configuration.

    Returns:
        Dict with paths to the produced float and INT8 TFLite models.
    """
    saved_model_dir = str(Path(cfg.export.onnx_path).with_suffix("")) + "_saved_model"
    onnx_to_saved_model(cfg.export.onnx_path, saved_model_dir)

    float_path = convert_to_tflite(saved_model_dir, cfg.export.tflite_path, quantize_int8=False)

    n_ecg = int(cfg.preprocessing.target_fs_ecg * cfg.window.seconds)
    n_pcg = int(cfg.preprocessing.target_fs_pcg * cfg.window.seconds)
    rep_dataset = _representative_dataset_factory(n_ecg, n_pcg)
    int8_path = convert_to_tflite(
        saved_model_dir, cfg.export.tflite_int8_path, quantize_int8=True, representative_dataset=rep_dataset
    )

    return {"tflite_float": float_path, "tflite_int8": int8_path}


if __name__ == "__main__":
    setup_logging()
    config = load_config("config.yaml")
    export_full_pipeline(config)
