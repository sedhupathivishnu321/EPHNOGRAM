"""Export a trained LMFCNet checkpoint to ONNX."""

from __future__ import annotations

import logging
from pathlib import Path

import onnx
import torch

from src.config import Config, load_config, setup_logging
from src.models.lightweight_model import LMFCNet

logger = logging.getLogger(__name__)


def export_to_onnx(cfg: Config, checkpoint_path: str = "weights/lmfcnet_best.pt") -> str:
    """Export the model to ONNX with dynamic batch axis.

    Args:
        cfg: Global configuration (provides input shapes and export path).
        checkpoint_path: Path to the trained PyTorch checkpoint.

    Returns:
        Path to the written ONNX file.
    """
    model = LMFCNet.from_config(cfg.model)
    ckpt_path = Path(checkpoint_path)
    if ckpt_path.exists():
        checkpoint = torch.load(ckpt_path, map_location="cpu")
        model.load_state_dict(checkpoint["model_state_dict"])
        logger.info("Loaded checkpoint from %s for export", ckpt_path)
    else:
        logger.warning("Checkpoint %s not found; exporting randomly initialized weights.", ckpt_path)
    model.eval()

    n_ecg = int(cfg.preprocessing.target_fs_ecg * cfg.window.seconds)
    n_pcg = int(cfg.preprocessing.target_fs_pcg * cfg.window.seconds)
    dummy_ecg = torch.randn(1, 1, n_ecg)
    dummy_pcg = torch.randn(1, 1, n_pcg)

    out_path = Path(cfg.export.onnx_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    try:
        torch.onnx.export(
            model,
            (dummy_ecg, dummy_pcg),
            str(out_path),
            input_names=["ecg", "pcg"],
            output_names=["logits"],
            dynamic_axes={"ecg": {0: "batch"}, "pcg": {0: "batch"}, "logits": {0: "batch"}},
            opset_version=cfg.export.opset,
        )
    except Exception:
        # Fall back to the legacy TorchScript-based exporter if the newer
        # dynamo-based exporter's optional dependencies (e.g. onnxscript)
        # are unavailable in the current environment.
        logger.warning("Default ONNX exporter failed; retrying with dynamo=False (legacy TorchScript exporter).")
        torch.onnx.export(
            model,
            (dummy_ecg, dummy_pcg),
            str(out_path),
            input_names=["ecg", "pcg"],
            output_names=["logits"],
            dynamic_axes={"ecg": {0: "batch"}, "pcg": {0: "batch"}, "logits": {0: "batch"}},
            opset_version=cfg.export.opset,
            dynamo=False,
        )

    onnx_model = onnx.load(str(out_path))
    onnx.checker.check_model(onnx_model)
    logger.info("ONNX model exported and validated: %s", out_path)
    return str(out_path)


if __name__ == "__main__":
    setup_logging()
    config = load_config("config.yaml")
    export_to_onnx(config)
