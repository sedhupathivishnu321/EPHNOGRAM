"""Digital filtering utilities: bandpass filter bank + notch filter.

Supports Bessel, Butterworth, Chebyshev Type I, Elliptic, and FIR bandpass
designs so that comparison experiments between filter families are possible,
as required by the project specification.
"""

from __future__ import annotations

import logging

import numpy as np
from scipy import signal

logger = logging.getLogger(__name__)

_SUPPORTED_FILTERS = ("bessel", "butterworth", "chebyshev1", "elliptic", "fir")


def design_bandpass(
    filter_type: str,
    lowcut: float,
    highcut: float,
    fs: float,
    order: int = 2,
    numtaps: int = 101,
) -> tuple[np.ndarray, np.ndarray]:
    """Design a bandpass filter and return (b, a) or (b, [1.0]) for FIR.

    Args:
        filter_type: One of 'bessel', 'butterworth', 'chebyshev1', 'elliptic', 'fir'.
        lowcut: Lower cutoff frequency in Hz.
        highcut: Upper cutoff frequency in Hz.
        fs: Sampling frequency in Hz.
        order: Filter order (IIR designs) — ignored for FIR (uses numtaps instead).
        numtaps: Number of FIR taps (only used when filter_type == 'fir').

    Returns:
        Tuple of filter coefficients (b, a). For FIR filters, a = [1.0].

    Raises:
        ValueError: If filter_type is unsupported or cutoffs are invalid.
    """
    filter_type = filter_type.lower()
    if filter_type not in _SUPPORTED_FILTERS:
        raise ValueError(f"Unsupported filter_type '{filter_type}'. Choose from {_SUPPORTED_FILTERS}")

    nyq = 0.5 * fs
    low = lowcut / nyq
    high = highcut / nyq
    if not (0 < low < high < 1):
        raise ValueError(f"Invalid cutoffs: lowcut={lowcut}, highcut={highcut}, fs={fs}")

    if filter_type == "bessel":
        b, a = signal.bessel(order, [low, high], btype="bandpass", analog=False, norm="phase")
    elif filter_type == "butterworth":
        b, a = signal.butter(order, [low, high], btype="bandpass")
    elif filter_type == "chebyshev1":
        b, a = signal.cheby1(order, rp=1, Wn=[low, high], btype="bandpass")
    elif filter_type == "elliptic":
        b, a = signal.ellip(order, rp=1, rs=40, Wn=[low, high], btype="bandpass")
    else:  # fir
        b = signal.firwin(numtaps, [low, high], pass_zero=False)
        a = np.array([1.0])

    return b, a


def apply_bandpass(
    x: np.ndarray,
    fs: float,
    lowcut: float,
    highcut: float,
    filter_type: str = "bessel",
    order: int = 2,
) -> np.ndarray:
    """Apply a zero-phase bandpass filter to a 1D signal.

    Args:
        x: Input signal, shape (n_samples,).
        fs: Sampling frequency in Hz.
        lowcut: Lower cutoff in Hz.
        highcut: Upper cutoff in Hz.
        filter_type: Filter family, see :func:`design_bandpass`.
        order: Filter order.

    Returns:
        Filtered signal, same shape as input.
    """
    b, a = design_bandpass(filter_type, lowcut, highcut, fs, order=order)
    padlen = min(len(x) - 1, 3 * max(len(a), len(b)))
    if padlen <= 0:
        logger.warning("Signal too short (%d samples) to filter reliably", len(x))
        return x
    return signal.filtfilt(b, a, x, padlen=padlen)


def apply_notch(x: np.ndarray, fs: float, freq: float = 50.0, q: float = 30.0) -> np.ndarray:
    """Apply an IIR notch filter to remove powerline interference.

    Args:
        x: Input signal.
        fs: Sampling frequency in Hz.
        freq: Notch center frequency in Hz (e.g. 50 or 60).
        q: Quality factor controlling notch bandwidth.

    Returns:
        Notch-filtered signal, same shape as input.
    """
    b, a = signal.iirnotch(freq, q, fs)
    padlen = min(len(x) - 1, 3 * max(len(a), len(b)))
    if padlen <= 0:
        return x
    return signal.filtfilt(b, a, x, padlen=padlen)


def remove_baseline(x: np.ndarray, fs: float, cutoff: float = 0.5) -> np.ndarray:
    """Remove baseline wander via a high-pass Butterworth filter.

    Args:
        x: Input signal.
        fs: Sampling frequency in Hz.
        cutoff: High-pass cutoff frequency in Hz.

    Returns:
        Baseline-corrected signal.
    """
    nyq = 0.5 * fs
    b, a = signal.butter(2, cutoff / nyq, btype="highpass")
    padlen = min(len(x) - 1, 3 * max(len(a), len(b)))
    if padlen <= 0:
        return x
    return signal.filtfilt(b, a, x, padlen=padlen)
