"""Normalization strategies: Z-score, Min-Max, Robust, Decimal scaling."""

from __future__ import annotations

import logging

import numpy as np

logger = logging.getLogger(__name__)

_SUPPORTED = ("zscore", "minmax", "robust", "decimal")


def zscore(x: np.ndarray, eps: float = 1e-8) -> np.ndarray:
    """Standardize to zero mean, unit variance."""
    mu, sigma = np.mean(x), np.std(x)
    return (x - mu) / (sigma + eps)


def minmax(x: np.ndarray, eps: float = 1e-8) -> np.ndarray:
    """Scale to the [0, 1] range."""
    x_min, x_max = np.min(x), np.max(x)
    return (x - x_min) / (x_max - x_min + eps)


def robust(x: np.ndarray, eps: float = 1e-8) -> np.ndarray:
    """Scale using median and interquartile range (robust to outliers)."""
    median = np.median(x)
    q75, q25 = np.percentile(x, [75, 25])
    iqr = q75 - q25
    return (x - median) / (iqr + eps)


def decimal_scaling(x: np.ndarray) -> np.ndarray:
    """Scale by moving the decimal point based on the maximum absolute value."""
    max_abs = np.max(np.abs(x))
    if max_abs == 0:
        return x.astype(np.float64)
    j = int(np.ceil(np.log10(max_abs + 1e-12)))
    return x / (10.0 ** j)


def normalize(x: np.ndarray, method: str = "zscore") -> np.ndarray:
    """Apply the requested normalization method to a signal.

    Args:
        x: Input signal array.
        method: One of 'zscore', 'minmax', 'robust', 'decimal'.

    Returns:
        Normalized signal.

    Raises:
        ValueError: If method is not supported.
    """
    method = method.lower()
    if method not in _SUPPORTED:
        raise ValueError(f"Unsupported normalization '{method}'. Choose from {_SUPPORTED}")
    x = np.asarray(x, dtype=np.float64)
    if method == "zscore":
        return zscore(x)
    if method == "minmax":
        return minmax(x)
    if method == "robust":
        return robust(x)
    return decimal_scaling(x)
