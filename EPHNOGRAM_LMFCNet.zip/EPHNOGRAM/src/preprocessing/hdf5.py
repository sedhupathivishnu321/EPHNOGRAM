"""End-to-end preprocessing pipeline: WFDB -> filtered/normalized windows -> HDF5.

Pipeline (matches project spec):

    WFDB -> read ECG+PCG -> quality assessment -> baseline removal ->
    bandpass filter -> notch filter -> normalization -> windowing (with
    overlap + rejection) -> HDF5 dataset (gzip compressed).
"""

from __future__ import annotations

import logging
from pathlib import Path

import h5py
import numpy as np
import wfdb
from scipy.signal import resample_poly

from src.config import Config
from src.preprocessing.filter import apply_bandpass, apply_notch, remove_baseline
from src.preprocessing.normalization import normalize
from src.preprocessing.verify import discover_records, has_required_channels
from src.preprocessing.windows import generate_windows

logger = logging.getLogger(__name__)


def _select_channel(record: "wfdb.Record", candidate_names: list[str]) -> np.ndarray | None:
    """Return the first matching channel's samples, or None if absent."""
    lower_sig_names = [s.lower() for s in record.sig_name]
    for candidate in candidate_names:
        if candidate.lower() in lower_sig_names:
            idx = lower_sig_names.index(candidate.lower())
            return record.p_signal[:, idx].astype(np.float64)
    return None


def _resample(x: np.ndarray, fs_in: float, fs_out: float) -> np.ndarray:
    """Resample a 1D signal from fs_in to fs_out using polyphase filtering."""
    if abs(fs_in - fs_out) < 1e-9:
        return x
    from math import gcd

    g = gcd(int(round(fs_in)), int(round(fs_out)))
    up = int(round(fs_out)) // g
    down = int(round(fs_in)) // g
    return resample_poly(x, up, down)


def preprocess_record(record_name: str, cfg: Config) -> list:
    """Run the full preprocessing pipeline on a single WFDB record.

    Args:
        record_name: Record base name (e.g. ``ECGPCG0001``).
        cfg: Global configuration.

    Returns:
        List of accepted :class:`~src.preprocessing.windows.Window` objects.
        Returns an empty list if the record is unreadable or missing
        required channels.
    """
    record_path = str(Path(cfg.dataset.path) / record_name)
    try:
        record = wfdb.rdrecord(record_path)
    except Exception as exc:  # noqa: BLE001
        logger.warning("Skipping %s: failed to read (%s)", record_name, exc)
        return []

    has_ecg, has_pcg = has_required_channels(record.sig_name, cfg)
    if not (has_ecg and has_pcg):
        logger.warning("Skipping %s: missing ECG or PCG channel (found %s)", record_name, record.sig_name)
        return []

    ecg_raw = _select_channel(record, cfg.dataset.ecg_channel_names)
    pcg_raw = _select_channel(record, cfg.dataset.pcg_channel_names)
    fs = float(record.fs)

    # Baseline removal
    ecg = remove_baseline(ecg_raw, fs, cutoff=0.5)
    pcg = pcg_raw.copy()

    # Bandpass filter (ECG / PCG specific bands)
    ecg = apply_bandpass(ecg, fs, cfg.ecg.lowcut, cfg.ecg.highcut,
                          filter_type=cfg.preprocessing.filter_type, order=cfg.preprocessing.order)
    pcg = apply_bandpass(pcg, fs, cfg.pcg.lowcut, cfg.pcg.highcut,
                          filter_type=cfg.preprocessing.filter_type, order=cfg.preprocessing.order)

    # Notch filter (powerline interference)
    ecg = apply_notch(ecg, fs, freq=cfg.preprocessing.notch_freq, q=cfg.preprocessing.notch_q)
    pcg = apply_notch(pcg, fs, freq=cfg.preprocessing.notch_freq, q=cfg.preprocessing.notch_q)

    # Resample to target rates (ECG/PCG can have distinct target rates)
    ecg = _resample(ecg, fs, cfg.preprocessing.target_fs_ecg)
    pcg = _resample(pcg, fs, cfg.preprocessing.target_fs_pcg)

    # Normalization
    ecg = normalize(ecg, cfg.preprocessing.normalization)
    pcg = normalize(pcg, cfg.preprocessing.normalization)

    # Windowing with rejection
    windows = generate_windows(ecg, pcg, cfg.preprocessing.target_fs_ecg, cfg.preprocessing.target_fs_pcg, cfg)
    accepted = [w for w in windows if w.accepted]
    logger.info("%s: %d/%d windows accepted", record_name, len(accepted), len(windows))
    return accepted


def infer_label_from_record_name(record_name: str) -> int:
    """Infer a binary label from record naming convention.

    EPHNOGRAM does not ship disease labels (it is a healthy-subject stress-test
    dataset); as a placeholder/example label we use rest (0) vs stress (1)
    based on common EPHNOGRAM naming conventions (e.g. a trailing stage
    number). Downstream users should replace this with metadata-driven labels
    (e.g. Bruce protocol stage) once the accompanying clinical metadata CSV is
    joined in.

    Args:
        record_name: WFDB record base name.

    Returns:
        Integer label (0 or 1).
    """
    return 0 if record_name.lower().endswith(("_baseline", "0001", "rest")) else 1


def build_hdf5_dataset(cfg: Config) -> str:
    """Run preprocessing over every record and store results in one HDF5 file.

    Args:
        cfg: Global configuration.

    Returns:
        Path to the created HDF5 file.
    """
    records = cfg.dataset.record_list or discover_records(cfg.dataset.path)
    out_path = Path(cfg.hdf5.output_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    total_windows = 0
    with h5py.File(out_path, "w") as hf:
        ecg_group = hf.create_group("ecg")
        pcg_group = hf.create_group("pcg")
        meta = {"record": [], "label": [], "sqi_ecg": [], "sqi_pcg": [], "window_index": []}

        for record_name in records:
            windows = preprocess_record(record_name, cfg)
            label = infer_label_from_record_name(record_name)
            for i, w in enumerate(windows):
                key = f"{record_name}_{i:05d}"
                ecg_group.create_dataset(
                    key, data=w.ecg.astype(np.float32),
                    compression=cfg.hdf5.compression, compression_opts=cfg.hdf5.compression_opts,
                )
                pcg_group.create_dataset(
                    key, data=w.pcg.astype(np.float32),
                    compression=cfg.hdf5.compression, compression_opts=cfg.hdf5.compression_opts,
                )
                meta["record"].append(record_name)
                meta["label"].append(label)
                meta["sqi_ecg"].append(w.sqi_ecg)
                meta["sqi_pcg"].append(w.sqi_pcg)
                meta["window_index"].append(i)
                total_windows += 1

        meta_group = hf.create_group("metadata")
        meta_group.create_dataset("record", data=np.array(meta["record"], dtype=h5py.string_dtype()))
        meta_group.create_dataset("label", data=np.array(meta["label"], dtype=np.int64))
        meta_group.create_dataset("sqi_ecg", data=np.array(meta["sqi_ecg"], dtype=np.float32))
        meta_group.create_dataset("sqi_pcg", data=np.array(meta["sqi_pcg"], dtype=np.float32))
        meta_group.create_dataset("window_index", data=np.array(meta["window_index"], dtype=np.int64))

    logger.info("Built HDF5 dataset with %d windows across %d records at %s", total_windows, len(records), out_path)
    return str(out_path)


if __name__ == "__main__":
    from src.config import load_config, setup_logging

    setup_logging()
    config = load_config("config.yaml")
    build_hdf5_dataset(config)
