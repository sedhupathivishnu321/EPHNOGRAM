"""Fixed-length windowing with overlap and quality-based rejection."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

import numpy as np

from src.config import Config, QualityConfig
from src.preprocessing.quality import assess_quality

logger = logging.getLogger(__name__)


@dataclass
class Window:
    ecg: np.ndarray
    pcg: np.ndarray
    start_sample_ecg: int
    start_sample_pcg: int
    sqi_ecg: float
    sqi_pcg: float
    accepted: bool
    reject_reasons: list[str] = field(default_factory=list)


def compute_window_params(fs: float, window_seconds: float, overlap: float) -> tuple[int, int]:
    """Compute window length and hop size (in samples) from time parameters.

    Args:
        fs: Sampling frequency in Hz.
        window_seconds: Window length in seconds.
        overlap: Fractional overlap between consecutive windows (0-1).

    Returns:
        Tuple (window_length_samples, hop_length_samples).
    """
    win_len = int(round(window_seconds * fs))
    hop_len = max(1, int(round(win_len * (1 - overlap))))
    return win_len, hop_len


def segment_signal(x: np.ndarray, win_len: int, hop_len: int) -> list[tuple[np.ndarray, int]]:
    """Split a 1D signal into overlapping fixed-length windows.

    Args:
        x: Input signal.
        win_len: Window length in samples.
        hop_len: Hop length in samples.

    Returns:
        List of (window_array, start_index) tuples. Trailing partial windows
        are dropped.
    """
    segments = []
    n = len(x)
    start = 0
    while start + win_len <= n:
        segments.append((x[start:start + win_len], start))
        start += hop_len
    return segments


def generate_windows(
    ecg: np.ndarray,
    pcg: np.ndarray,
    fs_ecg: float,
    fs_pcg: float,
    cfg: Config,
) -> list[Window]:
    """Generate synchronized ECG/PCG windows with quality-based rejection.

    Assumes ``ecg`` and ``pcg`` cover the same time span (already resampled
    to ``fs_ecg``/``fs_pcg`` respectively). Windows are generated on a shared
    time grid using the configured window length and overlap.

    Args:
        ecg: 1D ECG signal.
        pcg: 1D PCG signal.
        fs_ecg: ECG sampling frequency in Hz.
        fs_pcg: PCG sampling frequency in Hz.
        cfg: Global configuration.

    Returns:
        List of :class:`Window` objects, both accepted and rejected (callers
        typically filter on ``.accepted``).
    """
    win_len_ecg, hop_len_ecg = compute_window_params(fs_ecg, cfg.window.seconds, cfg.window.overlap)
    win_len_pcg, hop_len_pcg = compute_window_params(fs_pcg, cfg.window.seconds, cfg.window.overlap)

    ecg_segments = segment_signal(ecg, win_len_ecg, hop_len_ecg)
    pcg_segments = segment_signal(pcg, win_len_pcg, hop_len_pcg)

    n_windows = min(len(ecg_segments), len(pcg_segments))
    windows: list[Window] = []

    for i in range(n_windows):
        ecg_win, ecg_start = ecg_segments[i]
        pcg_win, pcg_start = pcg_segments[i]

        reasons: list[str] = []
        q_ecg = assess_quality(ecg_win, fs_ecg, (cfg.ecg.lowcut, cfg.ecg.highcut), cfg.quality)
        q_pcg = assess_quality(pcg_win, fs_pcg, (cfg.pcg.lowcut, cfg.pcg.highcut), cfg.quality)

        if cfg.window.reject_noisy and (q_ecg.is_noisy or q_pcg.is_noisy):
            reasons.append("noisy")
        if cfg.window.reject_clipped and (q_ecg.is_clipped or q_pcg.is_clipped):
            reasons.append("clipped")
        if cfg.window.reject_low_variance and (q_ecg.is_low_variance or q_pcg.is_low_variance):
            reasons.append("low_variance")
        if q_ecg.has_nan or q_ecg.has_inf or q_pcg.has_nan or q_pcg.has_inf:
            reasons.append("nan_or_inf")
        if q_ecg.is_flat or q_pcg.is_flat:
            reasons.append("flat")

        windows.append(
            Window(
                ecg=ecg_win,
                pcg=pcg_win,
                start_sample_ecg=ecg_start,
                start_sample_pcg=pcg_start,
                sqi_ecg=q_ecg.sqi,
                sqi_pcg=q_pcg.sqi,
                accepted=(len(reasons) == 0),
                reject_reasons=reasons,
            )
        )

    n_accepted = sum(w.accepted for w in windows)
    logger.info("Generated %d windows, %d accepted, %d rejected", len(windows), n_accepted, len(windows) - n_accepted)
    return windows
