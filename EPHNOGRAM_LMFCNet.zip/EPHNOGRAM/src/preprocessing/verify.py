"""Verification utilities for EPHNOGRAM WFDB records.

Scans ``data/WFDB`` for record headers, checks they can be opened with
``wfdb.rdrecord``, validates that expected ECG/PCG channels are present, and
produces a summary report (a pandas DataFrame) that can be saved to disk.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

import pandas as pd
import wfdb

from src.config import Config

logger = logging.getLogger(__name__)


def discover_records(wfdb_dir: str | Path) -> list[str]:
    """Find all WFDB record names (without extension) under a directory.

    Args:
        wfdb_dir: Directory containing ``.hea``/``.dat`` WFDB files.

    Returns:
        Sorted list of record base names (no extension), e.g. ``ECGPCG0001``.
    """
    wfdb_dir = Path(wfdb_dir)
    if not wfdb_dir.exists():
        raise FileNotFoundError(f"WFDB directory not found: {wfdb_dir}")
    headers = sorted(p.stem for p in wfdb_dir.glob("*.hea"))
    logger.info("Discovered %d WFDB records in %s", len(headers), wfdb_dir)
    return headers


def verify_record(record_path: str) -> dict:
    """Attempt to read a single WFDB record and validate its channels.

    Args:
        record_path: Path to the record without file extension, e.g.
            ``data/WFDB/ECGPCG0001``.

    Returns:
        A dict describing the record's validity and metadata.
    """
    result = {
        "record": Path(record_path).name,
        "readable": False,
        "n_channels": 0,
        "sig_names": [],
        "fs": None,
        "n_samples": 0,
        "duration_s": None,
        "error": None,
    }
    try:
        record = wfdb.rdrecord(record_path)
        result["readable"] = True
        result["n_channels"] = record.n_sig
        result["sig_names"] = list(record.sig_name)
        result["fs"] = record.fs
        result["n_samples"] = record.sig_len
        result["duration_s"] = record.sig_len / record.fs if record.fs else None
    except Exception as exc:  # noqa: BLE001 - we want to record any failure
        result["error"] = str(exc)
        logger.warning("Failed to read record %s: %s", record_path, exc)
    return result


def has_required_channels(sig_names: list[str], cfg: Config) -> tuple[bool, bool]:
    """Check whether ECG and PCG channels are present in a record.

    Args:
        sig_names: List of signal names as reported by WFDB.
        cfg: Global configuration (defines expected channel name aliases).

    Returns:
        Tuple ``(has_ecg, has_pcg)``.
    """
    lower_names = [s.lower() for s in sig_names]
    has_ecg = any(name.lower() in lower_names for name in cfg.dataset.ecg_channel_names)
    has_pcg = any(name.lower() in lower_names for name in cfg.dataset.pcg_channel_names)
    return has_ecg, has_pcg


def generate_dataset_report(cfg: Config, save_csv: Optional[str] = None) -> pd.DataFrame:
    """Verify every record in the dataset and build a summary report.

    Args:
        cfg: Global configuration.
        save_csv: Optional path to write the report as CSV.

    Returns:
        A pandas DataFrame, one row per record.
    """
    records = cfg.dataset.record_list or discover_records(cfg.dataset.path)
    rows = []
    for rec_name in records:
        rec_path = str(Path(cfg.dataset.path) / rec_name)
        info = verify_record(rec_path)
        if info["readable"]:
            has_ecg, has_pcg = has_required_channels(info["sig_names"], cfg)
        else:
            has_ecg, has_pcg = False, False
        info["has_ecg"] = has_ecg
        info["has_pcg"] = has_pcg
        info["usable"] = info["readable"] and has_ecg and has_pcg
        rows.append(info)

    df = pd.DataFrame(rows)
    n_usable = int(df["usable"].sum()) if not df.empty else 0
    logger.info("Verification complete: %d/%d records usable (ECG+PCG present)", n_usable, len(df))

    if save_csv:
        Path(save_csv).parent.mkdir(parents=True, exist_ok=True)
        df.to_csv(save_csv, index=False)
        logger.info("Saved verification report to %s", save_csv)

    return df


if __name__ == "__main__":
    from src.config import load_config, setup_logging

    setup_logging()
    config = load_config("config.yaml")
    report = generate_dataset_report(config, save_csv="outputs/dataset_report.csv")
    print(report.head())
