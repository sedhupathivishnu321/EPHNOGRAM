"""Signal quality assessment for ECG/PCG windows.

Detects NaNs, infinities, flat segments, low variance, clipping/saturation,
and excessive noise, then produces a composite Signal Quality Index (SQI)
in [0, 1] used to accept or reject windows before dataset creation.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass

import numpy as np
from scipy import signal as sp_signal

from src.config import QualityConfig

logger = logging.getLogger(__name__)


@dataclass
class QualityReport:
    has_nan: bool
    has_inf: bool
    is_flat: bool
    is_low_variance: bool
    is_clipped: bool
    is_noisy: bool
    sqi: float

    @property
    def is_valid(self) -> bool:
        return not (self.has_nan or self.has_inf or self.is_flat or self.is_clipped)


def check_nan_inf(x: np.ndarray) -> tuple[bool, bool]:
    """Return (has_nan, has_inf) for a signal array."""
    return bool(np.isnan(x).any()), bool(np.isinf(x).any())


def check_flat(x: np.ndarray, std_threshold: float) -> bool:
    """Detect a flat-lined (near-constant) signal."""
    return bool(np.nanstd(x) < std_threshold)


def check_low_variance(x: np.ndarray, min_variance: float) -> bool:
    """Detect abnormally low-variance segments."""
    return bool(np.nanvar(x) < min_variance)


def check_clipping(x: np.ndarray, clip_ratio_threshold: float) -> bool:
    """Detect saturation/clipping by counting samples at signal extremes.

    A sample is considered "clipped" if it equals (within floating tolerance)
    the min or max of the array, which is a common proxy for ADC saturation.
    """
    if x.size == 0:
        return True
    x_min, x_max = np.nanmin(x), np.nanmax(x)
    tol = 1e-6 * (abs(x_max) + abs(x_min) + 1e-12)
    n_clipped = int(np.sum((np.abs(x - x_min) < tol) | (np.abs(x - x_max) < tol)))
    clip_ratio = n_clipped / x.size
    return bool(clip_ratio > clip_ratio_threshold)


def estimate_snr_db(x: np.ndarray, fs: float, signal_band: tuple[float, float]) -> float:
    """Roughly estimate SNR (dB) via power ratio inside vs outside a band of interest.

    Args:
        x: Input signal.
        fs: Sampling frequency in Hz.
        signal_band: (low, high) Hz band assumed to contain the wanted signal.

    Returns:
        Estimated SNR in decibels. Higher is cleaner.
    """
    if x.size < 16:
        return -np.inf
    freqs, psd = sp_signal.welch(x, fs=fs, nperseg=min(256, x.size))
    low, high = signal_band
    in_band = (freqs >= low) & (freqs <= high)
    signal_power = np.sum(psd[in_band]) + 1e-12
    noise_power = np.sum(psd[~in_band]) + 1e-12
    return float(10 * np.log10(signal_power / noise_power))


def assess_quality(
    x: np.ndarray,
    fs: float,
    signal_band: tuple[float, float],
    cfg: QualityConfig,
) -> QualityReport:
    """Run the full signal-quality assessment pipeline on one window.

    Args:
        x: 1D signal array.
        fs: Sampling frequency in Hz.
        signal_band: Expected (low, high) Hz band for SNR estimation.
        cfg: Quality thresholds configuration.

    Returns:
        A populated :class:`QualityReport`.
    """
    has_nan, has_inf = check_nan_inf(x)
    x_clean = np.nan_to_num(x, nan=0.0, posinf=0.0, neginf=0.0)

    is_flat = check_flat(x_clean, cfg.flat_std_threshold)
    is_low_var = check_low_variance(x_clean, cfg.min_variance)
    is_clipped = check_clipping(x_clean, cfg.clip_ratio_threshold)
    snr_db = estimate_snr_db(x_clean, fs, signal_band)
    is_noisy = snr_db < cfg.noise_snr_db_threshold

    penalties = sum([has_nan, has_inf, is_flat, is_low_var, is_clipped, is_noisy])
    sqi = max(0.0, 1.0 - penalties / 6.0)

    return QualityReport(
        has_nan=has_nan,
        has_inf=has_inf,
        is_flat=is_flat,
        is_low_variance=is_low_var,
        is_clipped=is_clipped,
        is_noisy=is_noisy,
        sqi=sqi,
    )
