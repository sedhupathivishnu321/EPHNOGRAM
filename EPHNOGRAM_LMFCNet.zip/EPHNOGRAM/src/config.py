"""Configuration loading utilities for the LMFCNet EPHNOGRAM pipeline.

All runtime parameters are defined in a YAML file (see ``config.yaml`` at the
project root) and loaded into typed dataclasses here. No hardcoded
parameters should exist anywhere else in the codebase; every module should
receive a :class:`Config` instance (or one of its sub-configs).
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

import yaml

logger = logging.getLogger(__name__)


@dataclass
class DatasetConfig:
    path: str = "data/WFDB"
    record_list: Optional[list] = None
    ecg_channel_names: list = field(default_factory=lambda: ["ECG"])
    pcg_channel_names: list = field(default_factory=lambda: ["PCG", "PCG1", "PCG2"])


@dataclass
class PreprocessingConfig:
    filter_type: str = "bessel"
    order: int = 2
    notch_freq: float = 50.0
    notch_q: float = 30.0
    target_fs_ecg: int = 500
    target_fs_pcg: int = 1000
    normalization: str = "zscore"


@dataclass
class BandConfig:
    lowcut: float = 0.5
    highcut: float = 40.0


@dataclass
class QualityConfig:
    flat_std_threshold: float = 1e-6
    clip_ratio_threshold: float = 0.02
    min_variance: float = 1e-8
    noise_snr_db_threshold: float = -5.0


@dataclass
class WindowConfig:
    seconds: float = 5.0
    overlap: float = 0.5
    reject_noisy: bool = True
    reject_clipped: bool = True
    reject_low_variance: bool = True


@dataclass
class SplitConfig:
    train: float = 0.70
    val: float = 0.15
    test: float = 0.15
    subject_wise: bool = True


@dataclass
class HDF5Config:
    output_path: str = "outputs/ephnogram_dataset.h5"
    compression: str = "gzip"
    compression_opts: int = 4


@dataclass
class AugmentationConfig:
    enable: bool = True
    gaussian_noise_std: float = 0.01
    max_shift_ratio: float = 0.1
    amplitude_scale_range: list = field(default_factory=lambda: [0.9, 1.1])
    time_stretch_range: list = field(default_factory=lambda: [0.95, 1.05])
    random_crop_ratio: float = 0.9
    mixup_alpha: float = 0.2
    use_smote: bool = False


@dataclass
class ModelConfig:
    name: str = "LMFCNet"
    num_classes: int = 2
    base_channels: int = 16
    depth: int = 3
    attention_dim: int = 32
    dropout: float = 0.2


@dataclass
class TrainingConfig:
    batch_size: int = 32
    epochs: int = 100
    learning_rate: float = 0.001
    weight_decay: float = 1e-4
    optimizer: str = "adamw"
    scheduler: str = "cosine"
    loss: str = "cross_entropy"
    label_smoothing: float = 0.1
    focal_gamma: float = 2.0
    early_stopping_patience: int = 15
    num_workers: int = 2
    device: str = "auto"


@dataclass
class ExportConfig:
    onnx_path: str = "outputs/lmfcnet.onnx"
    tflite_path: str = "outputs/lmfcnet.tflite"
    tflite_int8_path: str = "outputs/lmfcnet_int8.tflite"
    opset: int = 17


@dataclass
class Config:
    seed: int = 42
    dataset: DatasetConfig = field(default_factory=DatasetConfig)
    preprocessing: PreprocessingConfig = field(default_factory=PreprocessingConfig)
    ecg: BandConfig = field(default_factory=lambda: BandConfig(0.5, 40.0))
    pcg: BandConfig = field(default_factory=lambda: BandConfig(20.0, 400.0))
    quality: QualityConfig = field(default_factory=QualityConfig)
    window: WindowConfig = field(default_factory=WindowConfig)
    split: SplitConfig = field(default_factory=SplitConfig)
    hdf5: HDF5Config = field(default_factory=HDF5Config)
    augmentation: AugmentationConfig = field(default_factory=AugmentationConfig)
    model: ModelConfig = field(default_factory=ModelConfig)
    training: TrainingConfig = field(default_factory=TrainingConfig)
    export: ExportConfig = field(default_factory=ExportConfig)

    root_dir: Path = field(default_factory=lambda: Path("."))


def _build(dc_type: type, data: dict[str, Any]):
    """Instantiate a dataclass from a dict, ignoring unknown keys safely."""
    valid_fields = {f for f in dc_type.__dataclass_fields__}
    filtered = {k: v for k, v in (data or {}).items() if k in valid_fields}
    return dc_type(**filtered)


def load_config(path: str | Path = "config.yaml") -> Config:
    """Load a :class:`Config` object from a YAML file.

    Args:
        path: Path to the YAML configuration file.

    Returns:
        A fully populated, typed :class:`Config` instance.

    Raises:
        FileNotFoundError: If the YAML file does not exist.
        yaml.YAMLError: If the YAML file cannot be parsed.
    """
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")

    with open(path, "r", encoding="utf-8") as fh:
        raw = yaml.safe_load(fh) or {}

    cfg = Config(
        seed=raw.get("seed", 42),
        dataset=_build(DatasetConfig, raw.get("dataset", {})),
        preprocessing=_build(PreprocessingConfig, raw.get("preprocessing", {})),
        ecg=_build(BandConfig, raw.get("ecg", {})),
        pcg=_build(BandConfig, raw.get("pcg", {})),
        quality=_build(QualityConfig, raw.get("quality", {})),
        window=_build(WindowConfig, raw.get("window", {})),
        split=_build(SplitConfig, raw.get("split", {})),
        hdf5=_build(HDF5Config, raw.get("hdf5", {})),
        augmentation=_build(AugmentationConfig, raw.get("augmentation", {})),
        model=_build(ModelConfig, raw.get("model", {})),
        training=_build(TrainingConfig, raw.get("training", {})),
        export=_build(ExportConfig, raw.get("export", {})),
        root_dir=path.parent.resolve(),
    )
    logger.info("Loaded configuration from %s", path)
    return cfg


def setup_logging(level: int = logging.INFO) -> None:
    """Configure root logging format for the whole project."""
    logging.basicConfig(
        level=level,
        format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )


if __name__ == "__main__":
    setup_logging()
    cfg = load_config("config.yaml")
    logger.info("Config loaded: model=%s, batch_size=%d", cfg.model.name, cfg.training.batch_size)
