"""Cross-modal attention: lets ECG features attend to PCG features and vice versa.

Implements a lightweight scaled dot-product cross-attention over the time
axis of each modality's feature map, projected to a shared low-dimensional
attention space (``attention_dim``) to keep the parameter count small.
"""

from __future__ import annotations

import math

import torch
from torch import nn


class CrossAttention1d(nn.Module):
    """Bidirectional lightweight cross-attention between two 1D feature maps.

    Args:
        channels_a: Channel count of the first modality's feature map.
        channels_b: Channel count of the second modality's feature map.
        attention_dim: Shared projection dimension for Q/K/V.
    """

    def __init__(self, channels_a: int, channels_b: int, attention_dim: int = 32) -> None:
        super().__init__()
        self.attention_dim = attention_dim

        self.q_a = nn.Conv1d(channels_a, attention_dim, kernel_size=1)
        self.k_b = nn.Conv1d(channels_b, attention_dim, kernel_size=1)
        self.v_b = nn.Conv1d(channels_b, attention_dim, kernel_size=1)
        self.out_a = nn.Conv1d(attention_dim, channels_a, kernel_size=1)

        self.q_b = nn.Conv1d(channels_b, attention_dim, kernel_size=1)
        self.k_a = nn.Conv1d(channels_a, attention_dim, kernel_size=1)
        self.v_a = nn.Conv1d(channels_a, attention_dim, kernel_size=1)
        self.out_b = nn.Conv1d(attention_dim, channels_b, kernel_size=1)

    @staticmethod
    def _attend(q: torch.Tensor, k: torch.Tensor, v: torch.Tensor) -> torch.Tensor:
        """Scaled dot-product attention over the time dimension.

        Args:
            q: Query, shape (B, D, Tq).
            k: Key, shape (B, D, Tk).
            v: Value, shape (B, D, Tk).

        Returns:
            Attended output, shape (B, D, Tq).
        """
        d = q.shape[1]
        q_t = q.transpose(1, 2)  # (B, Tq, D)
        k_t = k.transpose(1, 2)  # (B, Tk, D)
        scores = torch.bmm(q_t, k_t.transpose(1, 2)) / math.sqrt(d)  # (B, Tq, Tk)
        attn = torch.softmax(scores, dim=-1)
        v_t = v.transpose(1, 2)  # (B, Tk, D)
        out = torch.bmm(attn, v_t)  # (B, Tq, D)
        return out.transpose(1, 2)  # (B, D, Tq)

    def forward(self, feat_a: torch.Tensor, feat_b: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        """
        Args:
            feat_a: Feature map from modality A, shape (B, Ca, Ta).
            feat_b: Feature map from modality B, shape (B, Cb, Tb).

        Returns:
            Tuple (attended_a, attended_b), each a residual-updated feature
            map of the same shape as its input.
        """
        q_a, k_b, v_b = self.q_a(feat_a), self.k_b(feat_b), self.v_b(feat_b)
        attended_a = self.out_a(self._attend(q_a, k_b, v_b))

        q_b, k_a, v_a = self.q_b(feat_b), self.k_a(feat_a), self.v_a(feat_a)
        attended_b = self.out_b(self._attend(q_b, k_a, v_a))

        return feat_a + attended_a, feat_b + attended_b
