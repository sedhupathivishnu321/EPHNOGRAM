"""Feature fusion: combines pooled ECG and PCG representations for classification."""

from __future__ import annotations

import torch
from torch import nn


class FeatureFusion(nn.Module):
    """Global-pools each modality's feature map, then fuses via concat + MLP gate.

    Args:
        channels_a: Channels of modality A's feature map.
        channels_b: Channels of modality B's feature map.
        fused_dim: Output dimensionality of the fused representation.
        dropout: Dropout probability applied after fusion.
    """

    def __init__(self, channels_a: int, channels_b: int, fused_dim: int = 32, dropout: float = 0.2) -> None:
        super().__init__()
        self.pool_a = nn.AdaptiveAvgPool1d(1)
        self.pool_b = nn.AdaptiveAvgPool1d(1)
        self.fuse = nn.Sequential(
            nn.Linear(channels_a + channels_b, fused_dim),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout),
        )

    def forward(self, feat_a: torch.Tensor, feat_b: torch.Tensor) -> torch.Tensor:
        """
        Args:
            feat_a: (B, Ca, Ta) feature map from modality A.
            feat_b: (B, Cb, Tb) feature map from modality B.

        Returns:
            Fused representation of shape (B, fused_dim).
        """
        a = self.pool_a(feat_a).flatten(1)
        b = self.pool_b(feat_b).flatten(1)
        fused = torch.cat([a, b], dim=1)
        return self.fuse(fused)
