"""Reusable lightweight building-block layers for LMFCNet."""

from __future__ import annotations

import torch
from torch import nn


class DepthwiseSeparableConv1d(nn.Module):
    """Depthwise separable 1D convolution: depthwise conv + pointwise conv.

    Dramatically reduces parameter count vs. a standard Conv1d while
    preserving representational capacity, which is essential to keep
    LMFCNet under the 100K-parameter budget.
    """

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        kernel_size: int = 5,
        stride: int = 1,
        padding: int | None = None,
    ) -> None:
        super().__init__()
        if padding is None:
            padding = kernel_size // 2
        self.depthwise = nn.Conv1d(
            in_channels, in_channels, kernel_size, stride=stride, padding=padding,
            groups=in_channels, bias=False,
        )
        self.pointwise = nn.Conv1d(in_channels, out_channels, kernel_size=1, bias=False)
        self.bn = nn.BatchNorm1d(out_channels)
        self.act = nn.ReLU6(inplace=True)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.depthwise(x)
        x = self.pointwise(x)
        x = self.bn(x)
        return self.act(x)


class ResidualBlock1d(nn.Module):
    """Depthwise-separable residual block with an identity/projection shortcut."""

    def __init__(self, channels: int, kernel_size: int = 5) -> None:
        super().__init__()
        self.conv1 = DepthwiseSeparableConv1d(channels, channels, kernel_size)
        self.conv2 = DepthwiseSeparableConv1d(channels, channels, kernel_size)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        identity = x
        out = self.conv1(x)
        out = self.conv2(out)
        return out + identity


class SEBlock1d(nn.Module):
    """Squeeze-and-Excitation channel attention for 1D feature maps (lightweight)."""

    def __init__(self, channels: int, reduction: int = 8) -> None:
        super().__init__()
        hidden = max(1, channels // reduction)
        self.pool = nn.AdaptiveAvgPool1d(1)
        self.fc1 = nn.Linear(channels, hidden)
        self.fc2 = nn.Linear(hidden, channels)
        self.act = nn.ReLU(inplace=True)
        self.gate = nn.Sigmoid()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        b, c, _ = x.shape
        s = self.pool(x).view(b, c)
        s = self.act(self.fc1(s))
        s = self.gate(self.fc2(s)).view(b, c, 1)
        return x * s
