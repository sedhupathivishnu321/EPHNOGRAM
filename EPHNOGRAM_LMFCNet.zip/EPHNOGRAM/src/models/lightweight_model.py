"""LMFCNet: Lightweight Multimodal Feature Cross Network for ECG-PCG analysis.

Architecture:

    ECG -> Depthwise CNN backbone -> Residual blocks -+
                                                        |-> Cross Attention -> Fusion -> Classifier
    PCG -> Depthwise CNN backbone -> Residual blocks -+

Designed to stay under 100K parameters and <0.5MB (after INT8 quantization)
so it can be deployed on STM32-class microcontrollers via CMSIS-NN/TFLite
Micro.
"""

from __future__ import annotations

import torch
from torch import nn

from src.config import ModelConfig
from src.models.attention import CrossAttention1d
from src.models.backbone import SignalBackbone
from src.models.fusion import FeatureFusion


class LMFCNet(nn.Module):
    """Lightweight Multimodal Feature Cross Network.

    Args:
        num_classes: Number of output classes.
        base_channels: Channel width used in both backbones.
        depth: Number of residual blocks per backbone.
        attention_dim: Shared projection dim for cross-attention.
        dropout: Dropout probability in fusion/classifier head.
    """

    def __init__(
        self,
        num_classes: int = 2,
        base_channels: int = 16,
        depth: int = 3,
        attention_dim: int = 32,
        dropout: float = 0.2,
    ) -> None:
        super().__init__()
        self.ecg_backbone = SignalBackbone(in_channels=1, base_channels=base_channels, depth=depth, kernel_size=7)
        self.pcg_backbone = SignalBackbone(in_channels=1, base_channels=base_channels, depth=depth, kernel_size=9)

        self.cross_attention = CrossAttention1d(base_channels, base_channels, attention_dim=attention_dim)
        self.fusion = FeatureFusion(base_channels, base_channels, fused_dim=attention_dim, dropout=dropout)

        self.classifier = nn.Sequential(
            nn.Linear(attention_dim, attention_dim // 2),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout),
            nn.Linear(attention_dim // 2, num_classes),
        )

    def forward(self, ecg: torch.Tensor, pcg: torch.Tensor) -> torch.Tensor:
        """
        Args:
            ecg: Tensor of shape (B, 1, T_ecg).
            pcg: Tensor of shape (B, 1, T_pcg).

        Returns:
            Logits of shape (B, num_classes).
        """
        feat_ecg = self.ecg_backbone(ecg)
        feat_pcg = self.pcg_backbone(pcg)

        feat_ecg, feat_pcg = self.cross_attention(feat_ecg, feat_pcg)
        fused = self.fusion(feat_ecg, feat_pcg)
        return self.classifier(fused)

    @classmethod
    def from_config(cls, cfg: ModelConfig) -> "LMFCNet":
        """Build an :class:`LMFCNet` instance from a :class:`ModelConfig`."""
        return cls(
            num_classes=cfg.num_classes,
            base_channels=cfg.base_channels,
            depth=cfg.depth,
            attention_dim=cfg.attention_dim,
            dropout=cfg.dropout,
        )

    def count_parameters(self) -> int:
        """Return the total number of trainable parameters."""
        return sum(p.numel() for p in self.parameters() if p.requires_grad)


if __name__ == "__main__":
    model = LMFCNet()
    n_params = model.count_parameters()
    print(f"LMFCNet parameters: {n_params:,} ({n_params / 1000:.1f}K)")
    ecg_dummy = torch.randn(2, 1, 2500)  # 5s @ 500Hz
    pcg_dummy = torch.randn(2, 1, 5000)  # 5s @ 1000Hz
    out = model(ecg_dummy, pcg_dummy)
    print("Output shape:", out.shape)
