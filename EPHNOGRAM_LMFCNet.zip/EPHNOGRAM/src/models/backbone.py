"""Per-modality backbone: Depthwise CNN stem + residual blocks + SE attention.

Used identically for both the ECG and PCG branches of LMFCNet (each branch
has its own weights, but shares this architecture template).
"""

from __future__ import annotations

import torch
from torch import nn

from src.models.layers import DepthwiseSeparableConv1d, ResidualBlock1d, SEBlock1d


class SignalBackbone(nn.Module):
    """Lightweight single-modality backbone: stem -> residual stack -> SE -> pool.

    Args:
        in_channels: Number of input channels (1 for a single-lead signal).
        base_channels: Number of channels in the stem/residual blocks.
        depth: Number of residual blocks stacked.
        kernel_size: Convolution kernel size used throughout.
    """

    def __init__(
        self,
        in_channels: int = 1,
        base_channels: int = 16,
        depth: int = 3,
        kernel_size: int = 7,
    ) -> None:
        super().__init__()
        self.stem = DepthwiseSeparableConv1d(in_channels, base_channels, kernel_size, stride=2)
        self.blocks = nn.Sequential(*[ResidualBlock1d(base_channels, kernel_size) for _ in range(depth)])
        self.se = SEBlock1d(base_channels)
        self.downsample = nn.AvgPool1d(kernel_size=2)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: Tensor of shape (batch, in_channels, time).

        Returns:
            Feature map of shape (batch, base_channels, time_reduced).
        """
        x = self.stem(x)
        x = self.blocks(x)
        x = self.se(x)
        x = self.downsample(x)
        return x
